//
//  Lesya_WidgetApp.swift
//  Lesya Widget
//
//  Created by mll on 18.09.2023.
//

import SwiftUI

@main
struct Lesya_WidgetApp: App {
    @StateObject private var store = TipsStore()
    var body: some Scene {
        WindowGroup {
            lesyalist()
                .environmentObject(store)
        }
    }
}
