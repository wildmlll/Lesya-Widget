//
//  ProductsConstants.swift
//  lesyawidget
//
//  Created by mll on 22.09.2023.
//

import Foundation

let myTipProducts = [
    "com.imll.lesyawidget.tinyTip",
    "com.imll.lesyawidget.mediumTip"]
