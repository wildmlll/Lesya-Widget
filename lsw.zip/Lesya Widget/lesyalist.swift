//
//  ContentView.swift
//  lesyawidgett
//
//  Created by mll on 21.08.2023.
//

import SwiftUI
import WidgetKit
import Foundation
import StoreKit


struct CityData: Identifiable {
    let id = UUID()
    let name: String
    var sites: [CityData]?
    static func result() -> [CityData] {
        let pune1 = [CityData(name: "Василь Андрійович Симоненко"), CityData(name: "Народився 8 січня 1935р у селищі Біївці Лубенського району на Полтавщині.\n\nБатьки були колгоспниками, усе дитинство пройшло на селі у важкі воєнні та повоєнні часи\nУлітку 1962р міліціонери заарештували та жорстоко побили його. Відмовлялися друкувати твори, друзі відвернулися. На початку вересня 1963р ліг у лікарню, оскільки після побиття його мучили болі. Було діагностовано рак нирок. \nПомер 14 грудня 1963р у 28 років.")]
        let pune2 = [CityData (name: "Юрій Ігорович Андрухович"), CityData(name: "Народився 13 березня 1960 року у Станіславі (нині Івано-Франківськ). Закінчив редакторське відділення Українського поліграфічного Інституту у Львові (1982) та вищі літературні курси. У 1985 році за результатами публікації двох книг віршів прийнятий у СП України, у 1991 році — за ідейним переконанням виходить зі складу Союзу письменників разом з декількома колегами і стає ініціатором установи Асоціації українських письменників.\n\nПисьменник активно займається громадською діяльністю. Має яскраво виражену громадянську позицію, підтримуючи європейську інтеґрацію України.")]
        let pune3 = [CityData (name: "Нехай це буде нашим квестом🤫\n\nЗнайди вірш з якого була взята твоя цитатка та прочитай його повністю!\n\nНижче ти зможеш прочитати біографію письменників, дізнатись з чиїх віршів ми взяли рядки.\nМова завжди з тобою.")]
        
        return [CityData(name: "Звідки рядочки?", sites: pune3),
                CityData (name: "Симоненко", sites: pune1),
                CityData (name: "Андрухович", sites: pune2)]
    }
}

struct LeftAligned: ViewModifier {
    func body(content: Content) -> some View {
        HStack {
            content
            Spacer()
        }
    }
}


extension View {
    func leftAligned() -> some View {
        return self.modifier(LeftAligned())
    }
}


struct lesyalist: View {
    @EnvironmentObject var model: ContentModel
    @State public var tog1: Bool = ContentModel().togx1
    @EnvironmentObject private var store: TipsStore
    @State private var showTips = false
    @State private var showThanks = false

        var body: some View {
            
            //!param
            
            
                VStack{
                    HStack{
                        
                        Button("Нова цитатка"){
                            WidgetCenter.shared.reloadAllTimelines()
                        }
                        .padding()
                        .background(Color(red: 0, green: 0, blue: 0))
                        .foregroundStyle(.white)
                        .clipShape(Capsule())
                        //.background(Image("butim"))
                        Image("uiappin")
                            .resizable()
                            .frame(width: 80, height: 80)
                            .padding(.bottom, 2)
                        
                    }
                    
                    NavigationView {
                        List {
                            VStack{
                                
                                Text("   \"Мова росте елементарно,\n    разом з душею народу.\"")
                                    .leftAligned().frame(width: 355)
                                    .italic()
                                Text("Іван Франко     ")
                                    .frame(maxWidth: 400, alignment: .trailing)
                                    .bold()
                            }
                            
                            
                            
                            VStack{
                                ForEach(store.items) { item in
                                    configureProductVw(item)
                                }
                            }
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            
                            
                            
                            HStack{
                                Link("Підтримати Україну",
                                     destination: URL(string: "https://u24.gov.ua/")!)
                                .foregroundColor(.blue)
                                .font(.custom(
                                    "DIN Alternate",
                                    fixedSize: 17.5))
                                Text("▶️")
                            }
                           
                            
                            ForEach(CityData.result()) { city in
                                Section (header: EmptyView()) {
                                    OutlineGroup (city, children: \.sites) { site in
                                        Text (site.name)
                                        
                                    }
                                }
                            }
                            
                          
                        }
                    }
                    .foregroundColor(.black)
                    .listStyle(InsetGroupedListStyle())
                    .overlay(alignment: .bottom) {
                        if showThanks {
                            
                            VStack(spacing: 8) {
                                
                                Text("Спасибі друже🐾")
                                    .font(.system(.title2, design: .rounded).bold())
                                    .multilineTextAlignment(.center)
                                
                                Text("Твій донат дуже важливий для мене. Я витратив багато часу на розробку додатка. Бажаю приємного користування, та завжди смачної кави.")
                                    .font(.system(.body, design: .rounded))
                                    .multilineTextAlignment(.center)
                                    .padding(.bottom, 16)
                                
                                Button {
                                    showThanks.toggle()
                                } label: {
                                    Text("Закрити")
                                        .font(.system(.title3, design: .rounded).bold())
                                        .tint(.white)
                                        .frame(height: 55)
                                        .frame(maxWidth: .infinity)
                                        .background(.blue, in: RoundedRectangle(cornerRadius: 8,
                                                                                style: .continuous))
                                    
                                }
                            }
                            .padding(16)
                            .background(Color("card-background"), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .padding(.horizontal, 8)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                    }
                    .overlay {
                        
                        if showTips {
                            Color.black.opacity(0.8)
                                .ignoresSafeArea()
                                .transition(.opacity)
                                .onTapGesture {
                                    showTips.toggle()
                                    
                                }
                            
                        }
                    }
                    .animation(.spring(), value: showTips)
                    .animation(.spring(), value: showThanks)
                    .onChange(of: store.action) { action in
                                    
                        if action == .successful {
                            
                            showTips = false
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                
                                showThanks.toggle()

                            }
                            
                            store.reset()
                        }
                        
                    }
                    .alert(isPresented: $store.hasError, error: store.error) { }
                    
                    Text("🇺🇦©2023 wildmll")
                        .monospaced()
                    
                }
              
                
                    
        
                }
            }
            
            
        
        
        class ViewController: UIViewController {
            override func viewDidLoad() {
                super.viewDidLoad()
                overrideUserInterfaceStyle = .dark
            }
        }
        
        
        struct ContentView_Previews: PreviewProvider {
            static var previews: some View {
                lesyalist()
                    .environmentObject(TipsStore())
            }
        }

private extension lesyalist {
    
    
    func configureProductVw(_ item: Product) -> some View {
        
        
        HStack {
            
            VStack() {
                Text(item.displayName)
                    .font(.custom(
                        "DIN Alternate",
                        fixedSize: 17))
            }
            
            Spacer()
            
            Button(item.displayPrice) {
                Task {
                    await store.purchase(item)
                }
            }
            .tint(.blue)
            .buttonStyle(.bordered)
            .font(.callout.bold())
        }
        .padding(1.35)
        
    }
}
struct ProductsListView: View {
    
    @EnvironmentObject private var store: TipsStore

    var body: some View {
        
        ForEach(store.items) { item in
            ProductView(item: item)
        }
    }
}

struct ProductView: View {
    @EnvironmentObject private var store: TipsStore
    let item: Product
    var body: some View {
        HStack {
            
            VStack(alignment: .leading,
                   spacing: 3) {
                Text(item.displayName)
                    .font(.custom(
                        "DIN Alternate",
                        fixedSize: 17))
               
            }
            
            Spacer()
            
            Button(item.displayPrice) {
                Task {
                    await store.purchase(item)
                }
            }
            .tint(.blue)
            .buttonStyle(.bordered)
            .font(.callout.bold())
        }
    }
}
