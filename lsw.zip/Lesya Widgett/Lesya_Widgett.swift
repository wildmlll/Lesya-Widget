//
//  Lesya_Widget.swift
//  Lesya Widget
//
//  Created by mll on 21.08.2023.
//

import WidgetKit
import SwiftUI
import Intents
import Foundation


struct Provider: IntentTimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        SimpleEntry(date: Date(), configuration: ConfigurationIntent())
    }

    func getSnapshot(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (SimpleEntry) -> ()) {
        let entry = SimpleEntry(date: Date(), configuration: configuration)
        completion(entry)
    }

    func getTimeline(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        var entries: [SimpleEntry] = []
        
        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .hour, value: hourOffset, to: currentDate)!
            let entry = SimpleEntry(date: entryDate, configuration: configuration)
            entries.append(entry)
        }
        
        //
        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
        
        //let _nextUpdate = Calendar.autoupdatingCurrent.date(byAdding: .day, value: 1, to: Calendar.autoupdatingCurrent.startOfDay(for: Date()))!
        
    }
}
///NEW TIME LINE
//Calendar.startOfDay
// let nextUpdate = Calendar.autoupdatingCurrent.date(byAdding: .day, value: 1, to: Calendar.autoupdatingCurrent.startOfDay(for: Date()))!


struct SimpleEntry: TimelineEntry {
    let date: Date
    let configuration: ConfigurationIntent
}

extension UIColor {
   convenience init(red: Int, green: Int, blue: Int) {
       assert(red >= 0 && red <= 255, "Invalid red component")
       assert(green >= 0 && green <= 255, "Invalid green component")
       assert(blue >= 0 && blue <= 255, "Invalid blue component")

       self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
   }

   convenience init(rgb: Int) {
       self.init(
           red: (rgb >> 16) & 0xFF,
           green: (rgb >> 8) & 0xFF,
           blue: rgb & 0xFF
       )
   }
}


struct Lesya_WidgetEntryView : View {
    var entry: Provider.Entry
    
    
    let simonenko =
        ["Бо в тобі — великого народу \nНіжна і замріяна душа.",
        "І, бувало б, темніла зірка \nУ тумані тривожних дум.",
        "Ми ще йдемо. Ти щось мені говориш.\nТвоя краса цвіте в моїх очах.",
        "Ми ще йдемо. Ти щось мені говориш. \nТвоя краса цвіте в моїх очах.",
        "І час неспинний, стиснувши остроги, \nНад ними чвалить вранці і вночі.",
        "Все стерпить, хіба заплаче стиха, \nДивлячись на добрих малюків.",
        "Ти до мене прийшла не із казки чи сну, \nІ здалося мені, що стрічаю весну."]
    
    let andruhovich =
    ["Беріть мене, панове чортівня! \nТягніть у вир, де душу розітнуть.",
     "Може, у тім і спасіння - пізнати цю пору,\nніби останнє цвітіння. Єдине.",
     "Ти — мить свого народу, тільки мить.",
     "Україна ж — це країна барокко. \nМандрувати нею — для ока втіха.",
     "Я з розпуки тут ошаліти можу - \nвену вріжу, скажімо, чи всіх заріжу.",
     "Любий друже, приїдь, порятуй і вибав! \nПривези мені морфій, тютюн і тишу."]
    
    let lesya =
    ["Вітер зітха, мов дріада сумує,\nІз жалем глухим.",
    "З плачем ждемо тії години,\nКоли спадуть кайдани нас.",
    "Ні долі, ні волі у мене нема,\nЗосталася тільки надія одна.",
     "І страшніші, ніж сонні кошмари,\nТі привиддя безсонної ночі.",
     "Як зійде сонце правди та згоди,\nЯ тоді вічним сном буду спати.",
     "Сни мої щасливі!\nЯ люблю вас, хоч і знаю,\nЩо ви всі зрадливі…",
     "І знову прийдеться покинутій мені\nНе жити, а нести життя своє, мов кару.",
     "Чого ж се я слідом за ним блукаю?\nЧого? Сама не знаю.",
     "Не жаль мені, що я тебе кохаю,\nТа в нас дороги різно розійшлись.",
     "І знову замовкне… як глухо, як тихо…\nОй лихо!",
     "Нехай палає, не дає спокою,\nПоки душа терпіти силу має.",
     "Хай серце плаче, б’ється, рветься з туги,\nХай не дає спокою, хай палає."]
    
    let shevchenko =
    ["Ходімо дальше, дальше слава,\nА слава — заповідь моя.",
    "Нехай собі. А бог поможе,\nІ так забудеться колись.",
    "Ой піду я боса полем,\nПошукаю свою долю.",
    "І мертвим, і живим, і ненарожденним.",
    "Присплять, лукаві, і в огні\nЇї, окраденую, збудять…\nОх, не однаково мені.",
    "Кайдани порвіте\nІ вражою злою кров’ю\nВолю окропіте.",
    "Лежить попіл на розпутті,\nА в попелі тліє\nІскра вогню великого.",
    "Он піду я степом-лугом\nТа розважу свою тугу.",
    "Ну що б, здавалося, слова…\nСлова та голос — більш нічого.",
    "Сади зелені, погнили\nБіленькі хати, повалялись,\nСтави бур’яном поросли.",
    "Щоб потім сміятись,\nЩоб з тебе сміятись,\nЩоб тебе добити…"]
    
    let kostenko =
    ["",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    ""]
    let cont = Int.random(in: 0..<1)
    var body: some View {
        let tvir = [simonenko.randomElement()!, andruhovich.randomElement()!, lesya.randomElement()!, shevchenko.randomElement()!]
        let tvirmain = tvir.randomElement()!
       
        ZStack{
            let bglg = ["bgl1","bgl3","bgl6","bgl7","bgl1","bgl8","bgl5"]
            let colpal = [0xccccda, 0xc3c2cc, 0xc7d9d8, 0xb9e2e1, 0xccdacd, 0xd3d9c7, 0xcad9c7,0xd7eed3,0xcdecd8, 0xcee0c8]
            Color(UIColor(rgb: colpal.randomElement()!))
            
            Image(bglg.randomElement()!)
            // if  lesyalist(tog1: <#T##Bool#>) == true{
            
            //tvir.randomElement()!
            ZStack{
                Text(tvirmain)
                    .font(.custom(
                        "DIN Alternate",
                        fixedSize: 17.4))
                    .foregroundStyle(.black)
                    
                //Text("Симоненко В. A.")
               //  .font(.custom("DIN Alternate",fixedSize: 10))
               //  .italic()
                // .padding(.top, 80)
                // .padding(.trailing, 0)
                 //.foregroundColor(Color(UIColor(rgb: 0x242424)))
                 //.foregroundColor(Color(UIColor(rgb: colpal.randomElement()!)))
            }
            
        }
    }
}


struct Lesya_Widget: Widget {
    let kind: String = "Lesya_Widget"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: ConfigurationIntent.self, provider: Provider()) { entry in
            Lesya_WidgetEntryView(entry: entry)
            
        }
        .configurationDisplayName("Віджет з цитатою")
        .description("Вірші на екрані прибирають рани на душі.")
        .supportedFamilies([.systemMedium])
        
       
      
    }
}


struct Lesya_Widget_Previews: PreviewProvider {
    static var previews: some View {
        Lesya_WidgetEntryView(entry: SimpleEntry(date: Date(), configuration: ConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemMedium))
    }
}
