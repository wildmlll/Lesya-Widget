//
//  Lesya_WidgettBundle.swift
//  Lesya Widgett
//
//  Created by mll on 18.09.2023.
//

import WidgetKit
import SwiftUI

@main
struct Lesya_WidgettBundle: WidgetBundle {
    var body: some Widget {
        Lesya_Widget()
    }
}
